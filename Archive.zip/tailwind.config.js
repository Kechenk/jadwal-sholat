/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./public/*{html,js}"],
  theme: {
    extend: {
      fontFamily: {
        jakarta: ["jakarta-font", "std"],
        arab: ["arabic-font", "std"],
      },
      colors: {
        bawiru: "#42A8C3",
      },
    },
  },
  plugins: [],
};
